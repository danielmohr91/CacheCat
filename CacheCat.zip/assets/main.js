/**
 * when the popup page is shown/created and ready
 * @param none
 */
$(function() {
	clearCache();
});	
